"""Sample docstring for __init__.py."""
