"""
Prompt functions for brain_games.py.

Functions:
    welcome() -> None
    welcome_user() -> string
    check_answer(
        user_answer: str,
        correct_answer: str,
        username: str
    ) -> None
"""
import prompt


def welcome():
    """Print 'Welcome to the Brain Games!' to console."""
    print('Welcome to the Brain Games!')


def welcome_user():
    """Prompt user for his name and print 'Hello, {username}'."""
    name = prompt.string('May I have your name? ')
    print('Hello, {0}!'.format(name))
    return name


def check_answer(user_answer, correct_answer, username: str):
    if user_answer == correct_answer:
        print('Correct!')
        return True
    elif user_answer != correct_answer:
        print("'{0}' is wrong answer ;(. Correct answer was '{1}'.".format(user_answer, correct_answer))
        print("Let's try again, {0}!".format(username))
        return False
